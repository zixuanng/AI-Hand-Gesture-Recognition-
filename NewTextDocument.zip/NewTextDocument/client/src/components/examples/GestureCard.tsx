import GestureCard from '../GestureCard';

export default function GestureCardExample() {
  return <GestureCard gesture="Stop" confidence={0.92} />;
}
