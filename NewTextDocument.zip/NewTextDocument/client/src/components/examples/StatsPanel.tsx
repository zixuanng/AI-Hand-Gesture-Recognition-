import StatsPanel from '../StatsPanel';

export default function StatsPanelExample() {
  return <StatsPanel totalRecognitions={127} averageConfidence={0.87} recognitionRate={2.5} />;
}
